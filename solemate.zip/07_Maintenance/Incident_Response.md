# Incident Response

- Khi phát hiện sự cố:
  1. Ghi nhận log, thông báo các bên liên quan.
  2. Phân tích nguyên nhân, khắc phục tạm thời nếu cần.
  3. Khắc phục triệt để, cập nhật tài liệu, log sự cố.
  4. Đánh giá lại quy trình để phòng ngừa lặp lại.
