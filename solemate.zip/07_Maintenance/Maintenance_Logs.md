# Maintenance Logs

| Date       | Action           | Description                | Performed By |
|------------|------------------|----------------------------|--------------|
| 20/11/2025 | Update           | Nâng cấp Node.js 18.0      | DevOps       |
| 22/11/2025 | Bugfix           | Sửa lỗi thanh toán Momo    | Backend Dev  |
