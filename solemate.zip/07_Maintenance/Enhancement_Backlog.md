# Enhancement Backlog

| ID   | Feature/Enhancement      | Priority | Status   | Requester   | Note                |
|------|-------------------------|----------|----------|-------------|---------------------|
| ENH1 | Thêm chức năng wishlist | Should   | Open     | User        |                     |
| ENH2 | Tối ưu tốc độ tìm kiếm  | Must     | In Prog. | PM          |                     |
