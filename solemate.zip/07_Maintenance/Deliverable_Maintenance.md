# 07. Maintenance

## 7.1 Enhancement Backlog
- Quy trình tiếp nhận, đánh giá, ưu tiên yêu cầu nâng cấp:
  1. Ghi nhận yêu cầu từ khách hàng, người dùng, nội bộ.
  2. Đánh giá tác động, ước lượng effort.
  3. Xếp hạng ưu tiên (Must/Should/Could/Won't).
  4. Đưa vào backlog, lên kế hoạch phát triển.
- Mẫu backlog:
| ID   | Feature/Enhancement      | Priority | Status   | Requester   | Note                |
|------|-------------------------|----------|----------|-------------|---------------------|
| ENH1 | Thêm chức năng wishlist | Should   | Open     | User        |                     |
| ENH2 | Tối ưu tốc độ tìm kiếm  | Must     | In Prog. | PM          |                     |

## 7.2 Maintenance Logs
- Ghi nhận lịch sử bảo trì, cập nhật hệ thống:
| Date       | Action           | Description                | Performed By |
|------------|------------------|----------------------------|--------------|
| 20/11/2025 | Update           | Nâng cấp Node.js 18.0      | DevOps       |
| 22/11/2025 | Bugfix           | Sửa lỗi thanh toán Momo    | Backend Dev  |

- Quy trình bảo trì định kỳ:
  1. Kiểm tra log hệ thống, backup dữ liệu hàng tuần.
  2. Cập nhật package, vá bảo mật hàng tháng.
  3. Đánh giá hiệu năng, tối ưu code hàng quý.

## 7.3 Performance Report
- Đánh giá hiệu năng định kỳ:
  - Số lượng request/ngày, thời gian phản hồi trung bình, số lỗi 5xx/4xx.
  - Đề xuất tối ưu: cache, refactor code, nâng cấp server.
- Mẫu báo cáo:
| Thời gian   | Số request | Avg Response (ms) | Error Rate (%) | Đề xuất cải tiến         |
|-------------|------------|-------------------|----------------|-------------------------|
| 11/2025     | 120,000    | 850               | 0.2            | Thêm cache Redis        |
| 12/2025     | 150,000    | 780               | 0.1            | Nâng cấp EC2 instance   |

## 7.4 Incident Response
- Khi phát hiện sự cố:
  1. Ghi nhận log, thông báo các bên liên quan.
  2. Phân tích nguyên nhân, khắc phục tạm thời nếu cần.
  3. Khắc phục triệt để, cập nhật tài liệu, log sự cố.
  4. Đánh giá lại quy trình để phòng ngừa lặp lại.
