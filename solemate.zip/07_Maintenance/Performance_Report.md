# Performance Report

| Thời gian   | Số request | Avg Response (ms) | Error Rate (%) | Đề xuất cải tiến         |
|-------------|------------|-------------------|----------------|-------------------------|
| 11/2025     | 120,000    | 850               | 0.2            | Thêm cache Redis        |
| 12/2025     | 150,000    | 780               | 0.1            | Nâng cấp EC2 instance   |
