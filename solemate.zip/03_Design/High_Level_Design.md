# High Level Design (HLD)

## System Architecture
- 3-tier: Presentation (React), Business Logic (Node.js/Express), Data (MongoDB)
- Authentication: JWT, OAuth2
- Payment Integration: VNPay, Momo

## ERD (Mermaid)
```mermaid
erDiagram
    USERS ||--o{ ORDERS : places
    USERS ||--o{ REVIEWS : writes
    PRODUCTS ||--o{ REVIEWS : receives
    PRODUCTS ||--o{ ORDERS : included_in
    ORDERS ||--|{ ORDER_ITEMS : contains
    PRODUCTS {
      string name
      string description
      float price
      string image
    }
    USERS {
      string email
      string password
      string role
    }
    ORDERS {
      date orderDate
      string status
      float total
    }
    ORDER_ITEMS {
      int quantity
      float price
    }
    REVIEWS {
      int rating
      string comment
      date createdAt
    }
```
