# Main API Endpoints

| Method | Endpoint             | Description                | Auth |
|--------|----------------------|----------------------------|------|
| POST   | /api/auth/register   | Đăng ký tài khoản          | No   |
| POST   | /api/auth/login      | Đăng nhập                  | No   |
| GET    | /api/products        | Danh sách sản phẩm         | No   |
| GET    | /api/products/:id    | Chi tiết sản phẩm          | No   |
| POST   | /api/orders          | Đặt hàng                   | Yes  |
| GET    | /api/orders          | Lịch sử đơn hàng           | Yes  |
| POST   | /api/reviews         | Đánh giá sản phẩm          | Yes  |
| GET    | /api/admin/users     | Quản lý người dùng         | Admin|
