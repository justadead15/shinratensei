# Accessibility Checklist

- [x] Đủ tương phản màu sắc (WCAG 2.1 AA)
- [x] Có thể điều hướng bằng bàn phím
- [x] Có nhãn cho các trường nhập liệu
- [x] Hỗ trợ đọc màn hình (screen reader)
- [x] Responsive trên mọi thiết bị
