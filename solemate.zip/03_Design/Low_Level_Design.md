# Low Level Design (LLD)

## Module Description
| Module         | Description                                 | Main Classes/Functions         |
|----------------|---------------------------------------------|-------------------------------|
| Auth           | Đăng ký, đăng nhập, xác thực                | AuthController, JWTService    |
| Product        | Quản lý sản phẩm, tìm kiếm, chi tiết        | ProductController, ProductDAO |
| Order          | Đặt hàng, thanh toán, theo dõi đơn          | OrderController, PaymentSvc   |
| Review         | Đánh giá sản phẩm                           | ReviewController, ReviewDAO   |
| Admin          | Quản lý người dùng, sản phẩm, đơn hàng      | AdminController               |

## Example API (OpenAPI YAML)
```yaml
paths:
  /api/products:
    get:
      summary: Lấy danh sách sản phẩm
      responses:
        '200':
          description: Danh sách sản phẩm
  /api/orders:
    post:
      summary: Đặt hàng
      security:
        - bearerAuth: []
      requestBody:
        content:
          application/json:
            schema:
              type: object
              properties:
                items:
                  type: array
                  items:
                    type: object
                    properties:
                      productId:
                        type: string
                      quantity:
                        type: integer
      responses:
        '201':
          description: Đơn hàng đã tạo
```
