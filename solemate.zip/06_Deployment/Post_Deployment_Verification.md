# Post-deployment Verification

- Kiểm tra log lỗi, monitor uptime
- Kiểm thử lại các chức năng chính trên production
- Đảm bảo không có lỗi nghiêm trọng phát sinh
