# Rollback Plan

1. Tạo backup database, file trước khi deploy.
2. Nếu deploy lỗi, rollback bằng Docker Compose hoặc restore snapshot EC2/RDS.
3. Thông báo các bên liên quan, ghi log sự cố.
