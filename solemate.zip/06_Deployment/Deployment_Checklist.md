# Deployment Checklist

- [x] Đã backup dữ liệu
- [x] Đã kiểm tra môi trường staging
- [x] Đã kiểm tra cấu hình .env
- [x] Đã kiểm tra healthcheck service
- [x] Đã xác nhận deploy thành công trên production
- [x] Đã gửi thông báo hoàn thành deploy
