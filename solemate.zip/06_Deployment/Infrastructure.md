# Infrastructure

- Triển khai trên AWS EC2, RDS, S3, CloudFront hoặc Azure VM, CosmosDB.
- Sử dụng Docker Compose để quản lý service.
- Sơ đồ hạ tầng (Mermaid):
```mermaid
graph TD
  User -->|HTTPS| CloudFront
  CloudFront --> EC2[App Server]
  EC2 --> RDS[(Database)]
  EC2 --> S3[(Static Files)]
```
