# CI/CD Pipeline

- Sử dụng GitHub Actions:
  - Push code → Tự động chạy lint, test, build Docker image, push lên Docker Hub, deploy lên AWS/Azure.
  - Ví dụ workflow:
```yaml
name: CI/CD
on:
  push:
    branches: [main]
jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v2
      - name: Set up Node.js
        uses: actions/setup-node@v2
        with:
          node-version: '18'
      - run: npm install
      - run: npm test
      - run: docker build -t solemate-backend .
      - run: docker push solemate-backend
```
