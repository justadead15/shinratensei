# Change Management Process

1. Tiếp nhận yêu cầu thay đổi từ khách hàng hoặc nội bộ.
2. Đánh giá tác động (thời gian, chi phí, phạm vi).
3. Trình bày với khách hàng/phê duyệt nội bộ.
4. Cập nhật tài liệu, kế hoạch, thông báo các bên liên quan.
5. Theo dõi và kiểm soát thay đổi.
