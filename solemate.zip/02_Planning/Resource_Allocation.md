# Resource Allocation

| Role        | Name         | FTE | Responsibility                |
|-------------|--------------|-----|-------------------------------|
| PM          | Nguyễn Văn A | 1.0 | Quản lý dự án, báo cáo        |
| Developer   | Trần Văn B   | 1.0 | Backend/API                   |
| Developer   | Lê Thị C     | 1.0 | Frontend/UI                   |
| Developer   | Phạm Văn D   | 1.0 | DevOps, Database              |
| Tester      | Nguyễn Thị E | 1.0 | Test case, kiểm thử           |
| Designer    | Lê Văn F     | 0.5 | UI/UX, wireframe              |
