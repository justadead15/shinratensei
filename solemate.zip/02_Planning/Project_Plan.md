# Project Plan

## Milestones & Timeline
| Milestone                | Start Date | End Date   | Deliverable                  |
|--------------------------|------------|------------|------------------------------|
| Requirement Analysis     | 16/09/2025 | 22/09/2025 | SRS, RTM                     |
| System Design            | 23/09/2025 | 06/10/2025 | HLD, LLD, ERD, Wireframes    |
| Development              | 07/10/2025 | 03/11/2025 | Source code, API, Unit Test  |
| Testing                  | 04/11/2025 | 17/11/2025 | Test Report, UAT             |
| Deployment & Maintenance | 18/11/2025 | 24/11/2025 | Deployed system, Docs        |

## Gantt Chart (Mermaid)
```mermaid
gantt
title SoleMate Project Plan
dateFormat  DD-MM-YYYY
section Analysis
Requirement Analysis :a1, 16-09-2025, 7d
section Design
System Design        :a2, after a1, 14d
section Development
Development          :a3, after a2, 28d
section Testing
Testing              :a4, after a3, 14d
section Deployment
Deployment & Maint.  :a5, after a4, 7d
```
