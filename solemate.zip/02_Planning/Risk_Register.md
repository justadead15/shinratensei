# Risk Register

| ID  | Risk                        | Impact | Likelihood | Mitigation Plan                        | Owner        |
|-----|-----------------------------|--------|------------|----------------------------------------|--------------|
| R1  | Trễ tiến độ                 | High   | Medium     | Theo dõi tiến độ, daily meeting        | PM           |
| R2  | Thiếu nhân sự               | High   | Low        | Backup nhân sự, training               | PM           |
| R3  | Lỗi bảo mật                 | High   | Medium     | Code review, kiểm thử bảo mật          | Dev, Tester  |
| R4  | Công nghệ mới, chưa quen    | Medium | Medium     | Đào tạo, POC trước khi phát triển      | Dev          |
| R5  | Yêu cầu thay đổi liên tục    | Medium | High       | Quản lý thay đổi, xác nhận lại với KH  | PM           |
