# Non-functional Requirements

| ID   | Requirement                  | Description                                                      | Acceptance Criteria                                  |
|------|------------------------------|------------------------------------------------------------------|------------------------------------------------------|
| NFR1 | Performance                  | Đáp ứng tối thiểu 1000 người dùng đồng thời                      | Đo kiểm tải với JMeter, không quá 2s cho mỗi thao tác |
| NFR2 | Usability                    | Giao diện thân thiện, hỗ trợ đa thiết bị                        | Đạt điểm Lighthouse > 90, responsive trên mobile      |
| NFR3 | Security                     | Tuân thủ OWASP, bảo vệ dữ liệu người dùng                        | Không có lỗ hổng OWASP Top 10, mã hóa dữ liệu         |
| NFR4 | Availability                 | Hệ thống uptime tối thiểu 99.5%                                  | Theo dõi uptime qua monitoring tool                   |
| NFR5 | Maintainability              | Dễ bảo trì, tài liệu đầy đủ, code có test                        | Đạt code coverage > 80%, có CI/CD                     |
