# Constraints

- Sử dụng Node.js (Express) cho backend, React cho frontend, MongoDB cho database.
- Tích hợp thanh toán VNPay/Momo.
- Triển khai trên AWS/Azure, sử dụng Docker.
- Tuân thủ tiêu chuẩn bảo mật OWASP, mã hóa dữ liệu nhạy cảm (AES256).
- Thời gian phát triển tối đa 10 tuần.
