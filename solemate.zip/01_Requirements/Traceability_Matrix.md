# Traceability Matrix (RTM)

| Req ID | SRS Section | Design Doc | Test Case | Status |
|--------|-------------|------------|-----------|--------|
| FR01   | 1.1.1       | HLD-1, LLD-1| TC-01, TC-02 | Open   |
| FR02   | 1.1.2       | HLD-2, LLD-2| TC-03, TC-04 | Open   |
| FR03   | 1.1.3       | HLD-3, LLD-3| TC-05, TC-06 | Open   |
| FR04   | 1.1.4       | HLD-4, LLD-4| TC-07, TC-08 | Open   |
| FR05   | 1.1.5       | HLD-5, LLD-5| TC-09, TC-10 | Open   |
| FR06   | 1.1.6       | HLD-6, LLD-6| TC-11, TC-12 | Open   |
| NFR1   | 1.2.1       | HLD-N1      | TC-N1       | Open   |
| NFR2   | 1.2.2       | HLD-N2      | TC-N2       | Open   |
| ...    | ...         | ...         | ...         | ...    |
