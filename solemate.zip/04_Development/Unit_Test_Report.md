# Unit Test Report

**Ngày kiểm thử:** 12/10/2025
**Người kiểm thử:** Lê Thị C

## Tổng quan
- Tổng số test case: 30
- Pass: 28
- Fail: 2
- Coverage: 82%

## Module đã test
- AuthController: Pass 100%
- ProductController: Pass 100%
- OrderController: 1 case fail (tạo đơn hàng thiếu thông tin)
- ReviewController: 1 case fail (đánh giá không hợp lệ)

## Đề xuất
- Sửa lỗi validate ở orderController và reviewController.
- Bổ sung test cho các trường hợp biên.
