const express = require('express');
const router = express.Router();
const reviewController = require('../controllers/reviewController');
const auth = require('../utils/authMiddleware');

router.post('/', auth, reviewController.create);
router.get('/:productId', reviewController.list);

module.exports = router;
