// Review Controller
const Review = require('../models/Review');

exports.create = async (req, res) => {
  const { productId, rating, comment } = req.body;
  const review = await Review.create({ userId: req.user.userId, productId, rating, comment });
  res.status(201).json(review);
};

exports.list = async (req, res) => {
  const reviews = await Review.find({ productId: req.params.productId });
  res.json(reviews);
};
