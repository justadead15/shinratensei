// Order Controller
const Order = require('../models/Order');

exports.create = async (req, res) => {
  const { items, total } = req.body;
  const order = await Order.create({ userId: req.user.userId, items, total });
  res.status(201).json(order);
};

exports.list = async (req, res) => {
  const orders = await Order.find({ userId: req.user.userId });
  res.json(orders);
};
