import React from 'react';
import { Link } from 'react-router-dom';

const ProductList = ({ products }) => (
  <div>
    <h3>Danh sách sản phẩm</h3>
    <ul>
      {products.map(p => (
        <li key={p._id}>
          <Link to={`/products/${p._id}`}>{p.name} - {p.price} VND</Link>
        </li>
      ))}
    </ul>
  </div>
);
export default ProductList;
