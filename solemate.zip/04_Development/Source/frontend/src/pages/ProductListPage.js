import React, { useEffect, useState } from 'react';

function ProductListPage() {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch('/api/products')
      .then(res => res.json())
      .then(data => {
        setProducts(data);
        setLoading(false);
      });
  }, []);

  if (loading) return <div>Đang tải...</div>;

  return (
    <div className="product-list-page">
      <h2>Sản phẩm</h2>
      <ul>
        {products.map(p => (
          <li key={p._id}>
            <img src={p.image} alt={p.name} width={80} />
            <div>{p.name}</div>
            <div>{p.price}₫</div>
            <a href={`/products/${p._id}`}>Xem chi tiết</a>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default ProductListPage;
