import React, { useEffect, useState } from 'react';
import ProductList from '../components/ProductList';
import api from '../services/api';

const HomePage = () => {
  const [products, setProducts] = useState([]);
  useEffect(() => {
    api.get('/products').then(res => setProducts(res.data));
  }, []);
  return (
    <div>
      <h1>SoleMate - Trang chủ</h1>
      <ProductList products={products} />
    </div>
  );
};
export default HomePage;
