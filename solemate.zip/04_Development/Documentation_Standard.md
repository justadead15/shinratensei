# Documentation

- Tất cả module phải có README.md mô tả chức năng, cách chạy, test
- API phải có file swagger.yaml cập nhật
