# API Documentation (OpenAPI)

- Tất cả endpoint phải có mô tả OpenAPI (swagger.yaml)
- Ví dụ:
```yaml
openapi: 3.0.0
info:
  title: SoleMate API
  version: 1.0.0
paths:
  /api/products:
    get:
      summary: Lấy danh sách sản phẩm
      responses:
        '200':
          description: Danh sách sản phẩm
```
