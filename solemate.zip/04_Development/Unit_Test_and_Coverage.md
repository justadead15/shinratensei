# Unit Test & Coverage

- Viết unit test cho controller, service, model (Jest/Mocha/React Testing Library)
- Coverage tối thiểu 80% statements, 70% branch
- Ví dụ:
```js
describe('ProductController', () => {
  it('should return product list', async () => {
    // ...test code...
  });
});
```
