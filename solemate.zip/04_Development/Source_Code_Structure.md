# Source Code Structure

```
/solemate/04_Development/Source_Scaffold/
  backend/
    src/
      controllers/
      models/
      routes/
      services/
      utils/
    tests/
    package.json
    .env.example
  frontend/
    src/
      components/
      pages/
      services/
      utils/
    tests/
    package.json
    .env.example
```
