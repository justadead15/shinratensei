# Coding Standards

- Tuân thủ chuẩn code JavaScript (ESLint, Prettier), React (Airbnb Style Guide).
- Đặt tên biến camelCase, tên class PascalCase, tên file kebab-case.
- Hàm/method < 30 dòng, mỗi file < 300 dòng.
- Comment rõ ràng cho function phức tạp, dùng JSDoc cho API.
- Không hardcode, dùng biến môi trường (dotenv).
