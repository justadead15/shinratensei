# Code Review & CI/CD

- Pull request phải được review bởi ít nhất 1 dev khác
- Chạy tự động lint, test trên GitHub Actions trước khi merge
- Không merge code fail CI/CD
