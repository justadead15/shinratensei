# User Acceptance Test (UAT)

- Chuẩn bị môi trường UAT, dữ liệu mẫu.
- Mời đại diện khách hàng kiểm thử các chức năng chính.
- Ghi nhận phản hồi, cập nhật nếu có lỗi hoặc yêu cầu điều chỉnh.
- Lấy xác nhận UAT sign-off trước khi triển khai chính thức.
