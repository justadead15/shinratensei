# Test Cases (Sample)

| TC ID | Module   | Test Case Description                | Steps                                      | Expected Result           |
|-------|----------|--------------------------------------|--------------------------------------------|--------------------------|
| TC-01 | Auth     | Đăng ký tài khoản hợp lệ             | Nhập email, mật khẩu, xác nhận OTP         | Đăng ký thành công       |
| TC-02 | Auth     | Đăng nhập với thông tin đúng         | Nhập email, mật khẩu                       | Đăng nhập thành công     |
| TC-03 | Product  | Tìm kiếm sản phẩm theo tên           | Nhập tên sản phẩm, nhấn tìm kiếm           | Hiển thị đúng sản phẩm   |
| TC-04 | Order    | Đặt hàng với giỏ hàng hợp lệ         | Thêm sản phẩm, nhập địa chỉ, thanh toán    | Đơn hàng tạo thành công  |
| TC-05 | Admin    | Thêm sản phẩm mới                    | Đăng nhập admin, nhập thông tin, lưu       | Sản phẩm được thêm mới  |
