# Test Plan

- Mục tiêu: Đảm bảo hệ thống đáp ứng yêu cầu chức năng, phi chức năng, bảo mật, hiệu năng và chấp nhận người dùng.
- Phạm vi: Toàn bộ module backend, frontend, API, tích hợp thanh toán, quản trị.
- Loại kiểm thử: Unit, Integration, System, UAT, Performance, Security.
- Công cụ: Jest, React Testing Library, JMeter, OWASP ZAP, Jira.
- Lịch kiểm thử: 04/11/2025 - 17/11/2025
