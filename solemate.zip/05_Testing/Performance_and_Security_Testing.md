# Performance & Security Testing

- Hiệu năng: Dùng JMeter kiểm tra tải 1000 user đồng thời, đo thời gian phản hồi, throughput.
- Bảo mật: Dùng OWASP ZAP kiểm tra các lỗ hổng phổ biến (XSS, SQLi, CSRF, ...).
- Checklist:
  - [x] Không lộ thông tin nhạy cảm qua log
  - [x] Không có lỗi injection
  - [x] Mã hóa dữ liệu nhạy cảm
  - [x] Session timeout hợp lý
