# Defect Management

- Công cụ: Jira
- Quy trình:
  1. Phát hiện lỗi, tạo ticket Jira (ghi rõ bước tái hiện, ảnh chụp màn hình).
  2. Gán mức độ ưu tiên (Critical/High/Medium/Low).
  3. Gán cho dev xử lý, cập nhật trạng thái (Open → In Progress → Resolved → Closed).
  4. Kiểm tra lại (retest), xác nhận fix.
  5. Báo cáo tổng hợp định kỳ.
